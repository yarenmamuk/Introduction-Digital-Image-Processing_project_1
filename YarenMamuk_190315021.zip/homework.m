org = imread('lighthouse.png');
 ri = imrotate(org,45);
 org_gray = rgb2gray(org);

 subplot(2,2,1) ; imshow(org), title('Original Image');
 subplot(2,2,2) ; imshow(ri) , title('Rotated Image');
 subplot(2,2,3) ; imshow(org_gray), title('GrayScale Image');
 subplot(2,2,4) ; imhist(org_gray), title('Histogram Image');

