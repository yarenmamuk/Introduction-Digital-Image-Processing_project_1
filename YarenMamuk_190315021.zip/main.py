from PIL import Image , ImageFilter
# original photo
image1 = Image.open('lighthouse.png')
image1.show()

# Resize the original photo
print(image1.size) # (480 , 640)
newSize = image1.resize((300,300))
newSize.show()

# It puts filter to original image. It is saved as 'lightHouse_mode.png'
image1.convert(mode = 'L').save('lightHouse_mode.png')
image2 = Image.open('lightHouse_mode.png')
image2.show()

# Resize the filter image
newSize1 = image2.resize((1280,728))
newSize1.show()

# It puts filter to original image with using ImageFilter .
image1.filter(ImageFilter.GaussianBlur()).save('lightHouse_blur.png')
image3 = Image.open('lightHouse_blur.png')
image3.show()
